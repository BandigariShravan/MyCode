﻿namespace Solid_Open_Closed_Principle
{
    public class DeveloperReport
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Level { get; set; }
        public int Workinghours { get; set; }
        public double HourlyRate { get; set; }
    }
}
